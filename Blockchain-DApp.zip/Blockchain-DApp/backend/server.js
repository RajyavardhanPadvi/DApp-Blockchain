const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use(limiter);

// Global variables
let provider;
let contract;
let contractAddress;
let adminWallet;
let isConnected = false;

// Load contract and connect
async function initializeBlockchain() {
  try {
    console.log('Initializing blockchain connection...');
    
    // Wait for deployment file
    const deploymentPath = '/app/deployments/contract.json';
    let attempts = 0;
    const maxAttempts = 30;
    
    while (!fs.existsSync(deploymentPath) && attempts < maxAttempts) {
      console.log(`Waiting for contract deployment... (attempt ${attempts + 1}/${maxAttempts})`);
      await new Promise(resolve => setTimeout(resolve, 2000));
      attempts++;
    }

    if (!fs.existsSync(deploymentPath)) {
      throw new Error('Contract deployment file not found');
    }

    const deployment = JSON.parse(fs.readFileSync(deploymentPath, 'utf8'));
    contractAddress = deployment.address;
    const abi = deployment.abi;

    console.log('Contract address:', contractAddress);

    // Connect to blockchain
    provider = new ethers.JsonRpcProvider('http://blockchain:8545');
    
    // Use the first account as admin (same as deployer)
    const privateKey = '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80';
    adminWallet = new ethers.Wallet(privateKey, provider);
    
    contract = new ethers.Contract(contractAddress, abi, adminWallet);

    // Verify connection
    const network = await provider.getNetwork();
    console.log('Connected to network:', network.chainId.toString());
    
    isConnected = true;
    console.log('Blockchain connection established successfully!');

  } catch (error) {
    console.error('Failed to initialize blockchain:', error.message);
    setTimeout(initializeBlockchain, 5000);
  }
}

// Middleware to check connection
const checkConnection = (req, res, next) => {
  if (!isConnected) {
    return res.status(503).json({ error: 'Blockchain connection not ready' });
  }
  next();
};

// API Routes

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    blockchain: isConnected ? 'connected' : 'disconnected',
    contractAddress: contractAddress || 'not deployed'
  });
});

// Get contract info
app.get('/api/contract', checkConnection, (req, res) => {
  res.json({ 
    address: contractAddress,
    network: 'localhost',
    chainId: 31337
  });
});

// Get election info
app.get('/api/election', checkConnection, async (req, res) => {
  try {
    const info = await contract.getElectionInfo();
    res.json({
      name: info[0],
      startTime: Number(info[1]),
      endTime: Number(info[2]),
      isActive: info[3],
      totalVotes: Number(info[4]),
      totalCandidates: Number(info[5]),
      totalVoters: Number(info[6])
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all candidates
app.get('/api/candidates', checkConnection, async (req, res) => {
  try {
    const result = await contract.getAllCandidates();
    const candidates = [];
    
    for (let i = 0; i < result[0].length; i++) {
      candidates.push({
        id: Number(result[0][i]),
        name: result[1][i],
        party: result[2][i],
        voteCount: Number(result[3][i])
      });
    }
    
    res.json(candidates);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get single candidate
app.get('/api/candidates/:id', checkConnection, async (req, res) => {
  try {
    const result = await contract.getCandidate(req.params.id);
    res.json({
      id: Number(result[0]),
      name: result[1],
      party: result[2],
      voteCount: Number(result[3])
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get voter status
app.get('/api/voter/:address', checkConnection, async (req, res) => {
  try {
    const result = await contract.getVoterStatus(req.params.address);
    res.json({
      isRegistered: result[0],
      hasVoted: result[1],
      votedCandidateId: Number(result[2])
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get winner
app.get('/api/winner', checkConnection, async (req, res) => {
  try {
    const result = await contract.getWinner();
    res.json({
      id: Number(result[0]),
      name: result[1],
      party: result[2],
      voteCount: Number(result[3])
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get remaining time
app.get('/api/remaining-time', checkConnection, async (req, res) => {
  try {
    const remaining = await contract.getRemainingTime();
    res.json({ remainingSeconds: Number(remaining) });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Cast vote (requires private key in body for demo purposes)
app.post('/api/vote', checkConnection, async (req, res) => {
  try {
    const { candidateId, voterPrivateKey } = req.body;
    
    if (!candidateId || !voterPrivateKey) {
      return res.status(400).json({ error: 'candidateId and voterPrivateKey required' });
    }

    const voterWallet = new ethers.Wallet(voterPrivateKey, provider);
    const voterContract = contract.connect(voterWallet);
    
    const tx = await voterContract.vote(candidateId);
    const receipt = await tx.wait();
    
    res.json({ 
      success: true, 
      transactionHash: receipt.hash,
      message: 'Vote cast successfully!'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Admin: Add candidate
app.post('/api/admin/candidate', checkConnection, async (req, res) => {
  try {
    const { name, party, adminKey } = req.body;
    
    if (!name || !party) {
      return res.status(400).json({ error: 'name and party required' });
    }

    const tx = await contract.addCandidate(name, party);
    const receipt = await tx.wait();
    
    res.json({ 
      success: true, 
      transactionHash: receipt.hash,
      message: 'Candidate added successfully!'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Admin: Register voter
app.post('/api/admin/register-voter', checkConnection, async (req, res) => {
  try {
    const { voterAddress } = req.body;
    
    if (!voterAddress) {
      return res.status(400).json({ error: 'voterAddress required' });
    }

    const tx = await contract.registerVoter(voterAddress);
    const receipt = await tx.wait();
    
    res.json({ 
      success: true, 
      transactionHash: receipt.hash,
      message: 'Voter registered successfully!'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Admin: Create election
app.post('/api/admin/election', checkConnection, async (req, res) => {
  try {
    const { name, durationMinutes } = req.body;
    
    if (!name || !durationMinutes) {
      return res.status(400).json({ error: 'name and durationMinutes required' });
    }

    const tx = await contract.createElection(name, durationMinutes);
    const receipt = await tx.wait();
    
    res.json({ 
      success: true, 
      transactionHash: receipt.hash,
      message: 'Election created successfully!'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Admin: End election
app.post('/api/admin/end-election', checkConnection, async (req, res) => {
  try {
    const tx = await contract.endElection();
    const receipt = await tx.wait();
    
    res.json({ 
      success: true, 
      transactionHash: receipt.hash,
      message: 'Election ended successfully!'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get test accounts (for demo)
app.get('/api/test-accounts', checkConnection, async (req, res) => {
  // Hardhat default test accounts
  const accounts = [
    { address: '0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266', privateKey: '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80', role: 'Admin' },
    { address: '0x70997970C51812dc3A010C7d01b50e0d17dc79C8', privateKey: '0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d', role: 'Voter 1' },
    { address: '0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC', privateKey: '0x5de4111afa1a4b94908f83103eb1f1706367c2e68ca870fc3fb9a804cdab365a', role: 'Voter 2' },
    { address: '0x90F79bf6EB2c4f870365E785982E1f101E93b906', privateKey: '0x7c852118294e51e653712a81e05800f419141751be58f605c371e15141b007a6', role: 'Voter 3' },
    { address: '0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65', privateKey: '0x47e179ec197488593b187f80a00eb0da91f1b9d0b13f8733639f19c30a34926a', role: 'Voter 4' },
    { address: '0x9965507D1a55bcC2695C58ba16FB37d819B0A4dc', privateKey: '0x8b3a350cf5c34c9194ca85829a2df0ec3153be0318b5e2d3348e872092edffba', role: 'Voter 5' }
  ];
  
  res.json(accounts);
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Backend server running on port ${PORT}`);
  initializeBlockchain();
});

